

<?php $__env->startSection('title'); ?>
    <title> Bales </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="/admin/products/add" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <h1> Add Product</h1>
                </div>
                <div class="col-6 d-flex justify-content-end">
                    <a class="mx-1"><button class="btn btn-primary" type="submit">Save</button></a>
                    <a href="/admin/products/"><span class="btn btn-warning">Cancel</span></a>
                </div>
            </div>

            
            <div class="mb-3">
                <label for="name" class="form-label">Product Name</label>
                <input type="text" name="name" class="form-control" id="name" placeholder="Mine Ditse" required>
            </div>

            
            <div class="mb-3">
                <label for="bale" class="form-label">Product Bale</label>
                <select class="form-select" id="bale" name="bale" required aria-label="Default select example">
                    <?php if(count($bales) > 0): ?>
                        <?php $__currentLoopData = $bales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bale->bale_id); ?>">
                                <?php echo e('B' . $bale->bale_id . ' (' . $bale->category_name.')'); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <option value="" disabled selected> NO BALE FOUND </option>
                    <?php endif; ?>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="formFile" class="form-label">Product Image</label>
                <input class="form-control" name="photo" type="file" accept="image/*" id="formFile">
            </div>

            
            <div class="mb-3">
                <label for="description" class="form-label">Product Description</label>
                <textarea class="form-control" name="description" id="description" rows="3"
                    placeholder="Some description about the category"></textarea>
            </div>

            
            <div class="mb-3">
                <label for="unit" class="form-label">Product Unit</label>
                <select class="form-select" id="unit" name="unit" required aria-label="Default select example">     
                        <option value="pc" selected> pc </option>
                        <option value="pc"> box </option>
                </select>
            </div>

            
            <div class="mb-3">
                <label for="price" class="form-label">Product Price</label>
                <input type="number" name="price" step=".01" class="form-control" id="price" placeholder="##.##" required>
            </div>

            
            <div class="mb-3">
                <label for="other" class="form-label">Other Details</label>
                <textarea class="form-control" name="other" id="other" rows="3"
                    placeholder="Additional details about the category"></textarea>
            </div>

        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Web Development\ctinmfgl\Laravel Training\Laravel 9\mineditse-app\resources\views/products/add.blade.php ENDPATH**/ ?>