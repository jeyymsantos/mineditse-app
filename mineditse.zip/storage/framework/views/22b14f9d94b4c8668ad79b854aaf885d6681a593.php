

<?php $__env->startSection('title'); ?>
    <title> Suppliers </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="/admin/suppliers/edit/<?php echo e($supplier['supplier_id']); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <h1> Edit  Supplier</h1>
                </div>
                <div class="col-6 d-flex justify-content-end">
                    <a class="mx-1"><button class="btn btn-primary" type="submit">Save</button></a>
                    <a href="/admin/suppliers/"><span class="btn btn-warning">Cancel</span></a>
                </div>
            </div>

            
            <div class="mb-3">
                <label for="name" class="form-label">Supplier Name</label>
                <input type="text" name="name" class="form-control" id="name" placeholder="Juan Dela Cruz" required value="<?php echo e($supplier['supplier_name']); ?>">
            </div>
            
            
            <div class="mb-3">
                <label for="address" class="form-label">Supplier Address</label>
                <textarea class="form-control" name="address" id="address" rows="2" placeholder="Brgy. Poblacion, Baliwag, Bulacan"> <?php echo e($supplier['supplier_address']); ?></textarea>
            </div>

            
            <div class="mb-3">
                <label for="phone" class="form-label">Supplier Phone</label>
                <input class="form-control" name="phone" id="phone" type="text" placeholder="09123456789" maxLength="11" required value="<?php echo e($supplier['supplier_phone']); ?>"></input>
            </div>

            
            <div class="mb-3">
                <label for="email" class="form-label">Supplier Email</label>
                <input class="form-control" name="email" id="email" type="email" placeholder="sample@gmail.com" value="<?php echo e($supplier['supplier_email']); ?>"></input>
            </div>

            
            <div class="mb-3">
                <label for="remarks" class="form-label">Supplier Other Details</label>
                <textarea class="form-control" name="remarks" id="remarks" rows="3" placeholder="Additional Details about the supplier."> <?php echo e($supplier['supplier_other_details']); ?></textarea>
            </div>

            
            <div class="mb-3">
                <label for="date" class="form-label">Supplier Registered Date</label>
                <input class="form-control" name="date" id="date" type="date" required value="<?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $supplier['supplier_registered_date'])->format('Y-m-d')); ?>"></input>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Web Development\ctinmfgl\Laravel Training\Laravel 9\mineditse-app\resources\views/suppliers/edit.blade.php ENDPATH**/ ?>