

<?php $__env->startSection('title'); ?>
    <title> Bales </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        
            <h1>HI CUSTOMER BITCH <?php echo e(Auth::user()->name); ?></h1>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Web Development\ctinmfgl\Laravel Training\Laravel 9\mineditse-app\resources\views/customers/landing_page.blade.php ENDPATH**/ ?>