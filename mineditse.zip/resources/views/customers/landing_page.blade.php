@extends('layouts.app')

@section('title')
    <title> Bales </title>
@endsection

@section('custom_css')
    <link rel="stylesheet" href="{{ asset('css/products.css') }}">
@endsection

@section('content')
    <div class="container">
        
            <h1>HI CUSTOMER BITCH {{ Auth::user()->name }}</h1>

    </div>
@endsection
