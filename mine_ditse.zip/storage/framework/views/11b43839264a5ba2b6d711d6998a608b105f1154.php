

<?php $__env->startSection('title'); ?>
    <title> Users Home Page </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <main id="main">

            <section id="about" class="container mt-5">
                <h1 class="mb-4"> All Products </h1>

                <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-3 mt-2 mb-3">
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(asset('img/Logo.png')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3><?php echo e($product->prod_name); ?></h3>                     
                            <p class="card-text">
                                <?php echo e($product->prod_price); ?> | <?php echo e($product->category_name); ?> 
                            </p>
                            <a href="#" class="btn btn-primary">Add to Cart</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                 

            </section>

        </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\myrav\OneDrive\Desktop\website\mineditse-app\resources\views/customers/landing_page.blade.php ENDPATH**/ ?>