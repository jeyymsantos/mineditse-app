

<?php $__env->startSection('title'); ?>
    <title> Bales </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container table-responsive">
    
        <div class="row">
            <div class="col-6">
                <h1> Categories</h1>
            </div>
            <div class="col-6 d-flex justify-content-end">
                <a href="/admin/category/add"><button class="btn btn-primary">Add Category</button></a>
            </div>
        </div>

        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Other Details</th>
                    <th scope="col" style="text-align: center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th  class="align-middle"scope="row"><?php echo e('C' .$category['category_id']); ?></th>
                        <td class="align-middle"><?php echo e($category['category_name']); ?></td>
                        <td class="align-middle"><?php echo e($category['category_description'] == null ? 'N/A' : $category['category_description']); ?></td>
                        <td class="align-middle"><?php echo e($category['category_other_details'] == null ? 'N/A' : $category['category_description']); ?></td>
                        
                        <td class="align-middle" style="text-align: center">
                            <a href="/admin/category/edit/<?php echo e($category['supplier_id']); ?>"><button class="btn btn-warning"><i class="bi-pencil"></i></button></a>
                            <a href="/admin/category/delete/<?php echo e($category['supplier_id']); ?>"><button class="btn btn-danger"><i class="bi-trash"></i></button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\myrav\OneDrive\Desktop\website\mineditse-app\resources\views/category/view.blade.php ENDPATH**/ ?>